'use strict';

/**
 * @ngdoc function
 * @name olimpoWebApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the olimpoWebApp
 */
 angular.module('olimpoWebApp.main',['ngRoute'])

 .config(['$routeProvider', function($routeProvider) {
 	$routeProvider.when('/main', {
 		templateUrl: 'main/main.html',
 		controller: 'MainCtrl'
 	});
 }])

 .controller('MainCtrl', function ($scope) {
 	$scope.awesomeThings = [
 	'HTML5 Boilerplate',
 	'AngularJS',
 	'Karma'
 	];
 });
